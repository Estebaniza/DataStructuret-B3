module com.tree {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.tree to javafx.fxml;
    exports com.tree;
}
