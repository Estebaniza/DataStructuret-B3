package com.tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Tree {

    public static class TreeNode {
        public Object data;
        public ArrayList<TreeNode> children;

        public TreeNode(Object data) {
            this.data = data;
            this.children = new ArrayList<>();
        }

        public void addChild(TreeNode child) {
            this.children.add(child);
        }

        public void addChild(Object childData) {
            TreeNode child = new TreeNode(childData);
            this.children.add(child);
        }
    }

    public TreeNode root;

    public Tree(TreeNode root) {
        this.root = root;
    }

    public void print() {
        print(this.root, 0);
    }

    private void print(TreeNode current, int level) {
        StringBuilder levelMarks = new StringBuilder();
        for (int i = 0; i < level; i++) {
            levelMarks.append("-- ");
        }

        System.out.println(levelMarks.toString() + current.data.toString());

        for (TreeNode child : current.children) {
            print(child, level + 1);
        }
    }

    public void preOrderTraversal(TreeNode current, StringBuilder result) {
        if (current == null) return;
        result.append(current.data).append("\n");
        for (TreeNode child : current.children) {
            preOrderTraversal(child, result); 
        }
    }

    public void postOrderTraversal(TreeNode current, StringBuilder result) {
        if (current == null) return;
        for (TreeNode child : current.children) {
            postOrderTraversal(child, result); 
        }
        result.append(current.data).append("\n");
    }

    public void breadthFirstTraversal(StringBuilder result) {
        if (this.root == null) return;
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(this.root);
        while (!queue.isEmpty()) {
            TreeNode current = queue.poll();
            result.append(current.data).append("\n"); 
            queue.addAll(current.children); 
        }
    }
    public void inOrderTraversal(TreeNode current, StringBuilder result) {
        if (current == null) return;

        int mid = current.children.size() / 2;

        for (int i = 0; i < mid; i++) {
            inOrderTraversal(current.children.get(i), result);
        }

        result.append(current.data).append("\n");

        for (int i = mid; i < current.children.size(); i++) {
            inOrderTraversal(current.children.get(i), result);
        }
    }

    public static void main(String[] args) {

        TreeNode root1 = new TreeNode("Electronics R'Us");
        TreeNode rd = new TreeNode("R&D");
        TreeNode sales = new TreeNode("Sales");
        TreeNode purchasing = new TreeNode("Purchasing");
        TreeNode manufacturing = new TreeNode("Manufacturing");

        root1.addChild(rd);
        root1.addChild(sales);
        root1.addChild(purchasing);
        root1.addChild(manufacturing);

        TreeNode domestic = new TreeNode("Domestic");
        TreeNode international = new TreeNode("International");
        sales.addChild(domestic);
        sales.addChild(international);

        TreeNode canada = new TreeNode("Canada");
        TreeNode sa = new TreeNode("S. America");
        TreeNode overseas = new TreeNode("Overseas");
        international.addChild(canada);
        international.addChild(sa);
        international.addChild(overseas);

        TreeNode africa = new TreeNode("Africa");
        TreeNode europe = new TreeNode("Europe");
        TreeNode asia = new TreeNode("Asia");
        TreeNode australia = new TreeNode("Australia");
        overseas.addChild(africa);
        overseas.addChild(europe);
        overseas.addChild(asia);
        overseas.addChild(australia);

        TreeNode tv = new TreeNode("TV");
        TreeNode cd = new TreeNode("CD");
        TreeNode tuner = new TreeNode("Tuner");
        manufacturing.addChild(tv);
        manufacturing.addChild(cd);
        manufacturing.addChild(tuner);

        Tree tree1 = new Tree(root1);
        
        System.out.println("Figura 8.2 (Electronics R'Us):");
        tree1.print();

        StringBuilder bfsResult = new StringBuilder();
        StringBuilder preOrderResult = new StringBuilder();
        StringBuilder postOrderResult = new StringBuilder();
        StringBuilder inOrderResult = new StringBuilder();

        // Recorrido BFS
        System.out.println("\nRecorrido BFS:");
        tree1.breadthFirstTraversal(bfsResult);
        System.out.println(bfsResult.toString()); 

        // Recorrido DFS Pre-Order
        System.out.println("\nRecorrido DFS Pre-Order:");
        tree1.preOrderTraversal(tree1.root, preOrderResult);
        System.out.println(preOrderResult.toString()); 

        // Recorrido DFS Post-Order
        System.out.println("\nRecorrido DFS Post-Order:");
        tree1.postOrderTraversal(tree1.root, postOrderResult);
        System.out.println(postOrderResult.toString()); 

        // Recorrido DFS In-Order
        System.out.println("\nRecorrido DFS In-Order:");
        tree1.inOrderTraversal(tree1.root, inOrderResult);
        System.out.println(inOrderResult.toString()); 
    }
}

