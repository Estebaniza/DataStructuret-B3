package figure54;

public class TestBSTDelete {
  public static void main(String[] args) {
      // Crear el árbol y agregar elementos
      BST<String> tree = new BST<>();
      insertElements(tree);
      
      // Imprimir el árbol inicial
      printTree(tree, "Initial tree:");

      // Eliminar elementos e imprimir el estado del árbol después de cada operación
      deleteAndPrint(tree, "George");
      deleteAndPrint(tree, "Adam");
      deleteAndPrint(tree, "Michael");
  }

  // Método para insertar los elementos en el árbol
  private static void insertElements(BST<String> tree) {
      tree.insert("George");
      tree.insert("Michael");
      tree.insert("Tom");
      tree.insert("Adam");
      tree.insert("Jones");
      tree.insert("Peter");
      tree.insert("Daniel");
  }

  // Método para eliminar un elemento y luego imprimir el árbol
  private static void deleteAndPrint(BST<String> tree, String element) {
      System.out.println("\nAfter delete " + element + ":");
      tree.delete(element); // Eliminar el elemento
      printTree(tree, "Tree after deletion of " + element + ":");
  }

  // Método para imprimir el árbol y su información de recorridos
  private static void printTree(BST<String> tree, String message) {
      System.out.println(message);
      System.out.print("Inorder (sorted): ");
      tree.inorder();
      System.out.print("\nPostorder: ");
      tree.postorder();
      System.out.print("\nPreorder: ");
      tree.preorder();
      System.out.println("\nThe number of nodes is " + tree.size());
  }
}
