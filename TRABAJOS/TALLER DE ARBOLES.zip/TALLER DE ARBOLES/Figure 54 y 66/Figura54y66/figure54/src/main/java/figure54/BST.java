package figure54;

import java.util.LinkedList;
import java.util.Queue;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

public class BST<E> implements Tree<E> {
    public TreeNode<E> root;
    public int size = 0;
    private Comparator<E> comparator;

    // Constructores
    public BST() {
        this.comparator = (e1, e2) -> ((Comparable<E>) e1).compareTo(e2);
    }

    public BST(Comparator<E> comparator) {
        this.comparator = comparator;
    }

    public BST(E[] objects) {
        this();
        for (E obj : objects) {
            add(obj);
        }
    }

    // Métodos de búsqueda e inserción
    @Override
    public boolean search(E e) {
        TreeNode<E> current = root;
        while (current != null) {
            int comparison = comparator.compare(e, current.element);
            if (comparison < 0) {
                current = current.left;
            } else if (comparison > 0) {
                current = current.right;
            } else {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean insert(E e) {
        if (root == null) {
            root = new TreeNode<>(e);
            size++;
            return true;
        }
        return insertRec(root, e);
    }

    // Inserción recursiva para simplificar el código
    private boolean insertRec(TreeNode<E> node, E e) {
        int comparison = comparator.compare(e, node.element);
        if (comparison < 0) {
            if (node.left == null) {
                node.left = new TreeNode<>(e);
                size++;
                return true;
            } else {
                return insertRec(node.left, e);
            }
        } else if (comparison > 0) {
            if (node.right == null) {
                node.right = new TreeNode<>(e);
                size++;
                return true;
            } else {
                return insertRec(node.right, e);
            }
        }
        return false; // Element is already present
    }

    // Métodos de recorrido (Inorden, Preorden, Postorden)
    @Override
    public void inorder() {
        inorderRec(root);
        System.out.println();
    }

    private void inorderRec(TreeNode<E> node) {
        if (node != null) {
            inorderRec(node.left);
            System.out.print(node.element + " ");
            inorderRec(node.right);
        }
    }

    @Override
    public void preorder() {
        preorderRec(root);
        System.out.println();
    }

    private void preorderRec(TreeNode<E> node) {
        if (node != null) {
            System.out.print(node.element + " ");
            preorderRec(node.left);
            preorderRec(node.right);
        }
    }

    @Override
    public void postorder() {
        postorderRec(root);
        System.out.println();
    }

    private void postorderRec(TreeNode<E> node) {
        if (node != null) {
            postorderRec(node.left);
            postorderRec(node.right);
            System.out.print(node.element + " ");
        }
    }

    // Método para obtener el tamaño del árbol
    @Override
    public int getSize() {
        return size;
    }

    // Métodos de eliminación
    @Override
    public boolean delete(E e) {
        if (root == null) return false;
        root = deleteRec(root, e);
        return root != null;
    }

    // Eliminar nodo recursivamente
    private TreeNode<E> deleteRec(TreeNode<E> node, E e) {
        if (node == null) return null;

        int comparison = comparator.compare(e, node.element);
        if (comparison < 0) {
            node.left = deleteRec(node.left, e);
        } else if (comparison > 0) {
            node.right = deleteRec(node.right, e);
        } else {
            // Caso 1: Nodo sin hijos o con un solo hijo
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            // Caso 2: Nodo con dos hijos
            node.element = minValue(node.right);
            node.right = deleteRec(node.right, node.element);
        }
        return node;
    }

    // Encontrar el valor mínimo en un subárbol
    private E minValue(TreeNode<E> node) {
        E minValue = node.element;
        while (node.left != null) {
            minValue = node.left.element;
            node = node.left;
        }
        return minValue;
    }

    // Métodos de recorrido en anchura (BFS)
    public void bfs() {
        if (root == null) return;

        Queue<TreeNode<E>> queue = new LinkedList<>();
        queue.offer(root);

        while (!queue.isEmpty()) {
            TreeNode<E> current = queue.poll();
            System.out.print(current.element + " ");
            if (current.left != null) queue.offer(current.left);
            if (current.right != null) queue.offer(current.right);
        }
        System.out.println();
    }

    // Obtención de la raíz del árbol
    public TreeNode<E> getRoot() {
        return root;
    }

    // Método para obtener el camino desde la raíz hasta un nodo
    public ArrayList<TreeNode<E>> path(E e) {
        ArrayList<TreeNode<E>> path = new ArrayList<>();
        TreeNode<E> current = root;
        while (current != null) {
            path.add(current);
            int comparison = comparator.compare(e, current.element);
            if (comparison < 0) {
                current = current.left;
            } else if (comparison > 0) {
                current = current.right;
            } else {
                break;
            }
        }
        return path;
    }

    // Método para limpiar el árbol
    @Override
    public void clear() {
        root = null;
        size = 0;
    }

    // Clase interna para el nodo del árbol
    public static class TreeNode<E> {
        E element;
        TreeNode<E> left;
        TreeNode<E> right;

        public TreeNode(E element) {
            this.element = element;
        }
    }

    // Interfaz del iterador
    @Override
    public Iterator<E> iterator() {
        return new InorderIterator();
    }

    private class InorderIterator implements Iterator<E> {
        private ArrayList<E> list = new ArrayList<>();
        private int current = 0;

        public InorderIterator() {
            inorderToList(root);
        }

        private void inorderToList(TreeNode<E> node) {
            if (node != null) {
                inorderToList(node.left);
                list.add(node.element);
                inorderToList(node.right);
            }
        }

        @Override
        public boolean hasNext() {
            return current < list.size();
        }

        @Override
        public E next() {
            return list.get(current++);
        }

        @Override
        public void remove() {
            if (current == 0) throw new IllegalStateException();
            delete(list.get(--current));
            list.clear();
            inorderToList(root);
        }
    }
}
