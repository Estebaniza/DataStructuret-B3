package figure54;

public class TestBSTWithIterator {
  public static void main(String[] args) {
      // Crear el árbol e insertar los elementos
      BST<String> tree = new BST<>();
      insertElements(tree);
      
      // Imprimir los elementos usando el iterador
      printTreeWithIterator(tree);
  }

  // Método para insertar los elementos en el árbol
  private static void insertElements(BST<String> tree) {
      tree.insert("George");
      tree.insert("Michael");
      tree.insert("Tom");
      tree.insert("Adam");
      tree.insert("Jones");
      tree.insert("Peter");
      tree.insert("Daniel");
  }

  // Método para imprimir los elementos utilizando el iterador
  private static void printTreeWithIterator(BST<String> tree) {
      System.out.print("Elements in the tree (using iterator): ");
      for (String s : tree) { // Usar el foreach loop para iterar
          System.out.print(s.toUpperCase() + " ");
      }
      System.out.println();  // Nueva línea después de la salida
  }
}
