package figure54;

public class TestBST {
  public static void main(String[] args) {
      // Crear el árbol de cadenas
      BST<String> stringTree = new BST<>();
      insertStringElements(stringTree);
      performTreeOperations(stringTree);

      // Crear el árbol de enteros
      Integer[] numbers = {2, 4, 3, 1, 8, 5, 6, 7};
      BST<Integer> intTree = new BST<>(numbers);
      performTreeOperations(intTree);
  }

  // Método para insertar elementos en el árbol de cadenas
  private static void insertStringElements(BST<String> tree) {
      tree.insert("George");
      tree.insert("Michael");
      tree.insert("Tom");
      tree.insert("Adam");
      tree.insert("Jones");
      tree.insert("Peter");
      tree.insert("Daniel");
  }

  // Método para realizar y mostrar los recorridos en un árbol
  private static <E> void performTreeOperations(BST<E> tree) {
      // Recorrido Inorder
      System.out.print("Inorder: ");
      tree.inorder();

      // Recorrido Postorder
      System.out.print("\nPostorder: ");
      tree.postorder();

      // Recorrido Preorder
      System.out.print("\nPreorder (DFS): ");
      tree.preorder();

      // Recorrido BFS
      System.out.print("\nBFS Traversal: ");
      tree.bfs();

      // Número de nodos
      System.out.printf("\nThe number of nodes is: %d\n\n", tree.getSize());
  }
}

