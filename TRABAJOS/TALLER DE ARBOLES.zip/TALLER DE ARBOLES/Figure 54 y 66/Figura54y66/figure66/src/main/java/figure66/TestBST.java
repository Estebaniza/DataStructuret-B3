package figure66;

public class TestBST {
    public static void main(String[] args) {
      
      BST<Integer> tree = new BST<>();
      tree.insert(60);
        tree.insert(55);
        tree.insert(45);
        tree.insert(57);
        tree.insert(59);
        tree.insert(100);
        tree.insert(67);
        tree.insert(107);
        tree.insert(101);
  
      // Recorrido  Inorder
      System.out.print("Inorder : ");
      tree.inorder();
      // Recorrido  Postoder
      System.out.print("\nPostorder: ");
      tree.postorder();
      // Recorrido DFS Preorder
      System.out.print("\n DFS Preorder: ");
      tree.preorder();
      // Recorrido BFS
      System.out.print("\n BFS : ");
      tree.bfs(); // BFS
      System.out.print("\nEL NUMERO DE NODOS ES " + tree.getSize());
  

    }
  }
