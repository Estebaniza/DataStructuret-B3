package com.bstanimation;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

public class BTView extends Pane {
    public BST<Integer> tree; 
    public double radius = 15;
    public double vGap = 50;   

    // Constructor
    public BTView(BST<Integer> tree) {
        this.tree = tree;
        setStatus("Tree is empty");
    }

    public void setStatus(String msg) {
        getChildren().clear(); 
        getChildren().add(new Text(20, 20, msg));
    }

    public void displayTree() {
        this.getChildren().clear(); 

        if (tree.getRoot() != null) {

            displayTree(tree.getRoot(), getWidth() / 2, vGap, getWidth() / 4);
        }
    }

    
    public void displayTree(BST.TreeNode<Integer> root, double x, double y, double hGap) {
        if (root.left != null) {
            // Dibujar una línea hacia el nodo izquierdo
            getChildren().add(new Line(x - hGap, y + vGap, x, y));
            // Dibujar el subárbol izquierdo de manera recursiva
            displayTree(root.left, x - hGap, y + vGap, hGap / 2);
        }

        if (root.right != null) {
            // Dibujar una línea hacia el nodo derecho
            getChildren().add(new Line(x + hGap, y + vGap, x, y));
            // Dibujar el subárbol derecho de manera recursiva
            displayTree(root.right, x + hGap, y + vGap, hGap / 2);
        }

        // Mostrar el nodo actual como un círculo
        Circle circle = new Circle(x, y, radius);
        circle.setFill(Color.WHITE);
        circle.setStroke(Color.BLACK);
        getChildren().addAll(circle,
                new Text(x - 4, y + 4, root.element + ""));
    }
}

class BST<T extends Comparable<T>> {
    private TreeNode<T> root;

    public BST() {
        root = null;
    }

    public TreeNode<T> getRoot() {
        return root;
    }

    public void insert(T element) {
        root = insert(root, element);
    }

    private TreeNode<T> insert(TreeNode<T> node, T element) {
        if (node == null) {
            return new TreeNode<>(element);
        }

        if (element.compareTo(node.element) < 0) {
            node.left = insert(node.left, element);
        } else if (element.compareTo(node.element) > 0) {
            node.right = insert(node.right, element);
        }

        return node;
    }

    // Clase TreeNode que representa un nodo en el árbol
    public static class TreeNode<T> {
        T element;
        TreeNode<T> left, right;

        public TreeNode(T element) {
            this.element = element;
            this.left = this.right = null;
        }
    }

    public boolean search(int key) {
        throw new UnsupportedOperationException("Unimplemented method 'search'");
    }

    public void delete(int key) {

        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }
}
