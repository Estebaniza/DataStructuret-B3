package com.bstanimation;

class BST<T extends Comparable<T>> {
    public TreeNode<T> root;

    public BST() {
        root = null;
    }

    public TreeNode<T> getRoot() {
        return root;
    }

    public void insert(T key) {
        root = insert(root, key);
    }

    public TreeNode<T> insert(TreeNode<T> node, T key) {
        if (node == null) {
            return new TreeNode<>(key);
        }

        if (key.compareTo(node.element) < 0) {
            node.left = insert(node.left, key);
        } else if (key.compareTo(node.element) > 0) {
            node.right = insert(node.right, key);
        }

        return node;
    }

    public boolean search(T key) {
        return search(root, key);
    }

    public boolean search(TreeNode<T> node, T key) {
        if (node == null) {
            return false;
        }
        if (key.compareTo(node.element) < 0) {
            return search(node.left, key);
        } else if (key.compareTo(node.element) > 0) {
            return search(node.right, key);
        } else {
            return true;
        }
    }

    public void delete(T key) {
        root = delete(root, key);
    }

    public TreeNode<T> delete(TreeNode<T> node, T key) {
        if (node == null) return null;

        if (key.compareTo(node.element) < 0) {
            node.left = delete(node.left, key);
        } else if (key.compareTo(node.element) > 0) {
            node.right = delete(node.right, key);
        } else {
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            T minValue = findMin(node.right).element;
            node.element = minValue;
            node.right = delete(node.right, minValue);
        }
        return node;
    }

    public TreeNode<T> findMin(TreeNode<T> node) {
        while (node.left != null) node = node.left;
        return node;
    }

    public static class TreeNode<T> {
        T element;
        TreeNode<T> left, right;

        public TreeNode(T element) {
            this.element = element;
            this.left = this.right = null;
        }
    }
}
