module com.bstanimation {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.bstanimation to javafx.fxml;
    exports com.bstanimation;
}
