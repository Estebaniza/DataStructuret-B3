package com.figura83;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class TreeRepresenting {
    public static class TreeNode {
        public Object data;
        public ArrayList<TreeNode> children;

        public TreeNode(Object data) {
            this.data = data;
            this.children = new ArrayList<>();
        }

        public void addChild(TreeNode child) {
            this.children.add(child);
        }

        public void addChild(Object childData) {
            TreeNode child = new TreeNode(childData);
            this.children.add(child);
        }
    }

    public TreeNode root;

    public TreeRepresenting(TreeNode root) {
        this.root = root;
    }

    public void print() {
        print(this.root, 0);
    }

    public void print(TreeNode current, int level) {
        String levelMarks = "";
        for (int i = 0; i < level; i++) {
            levelMarks += "-- ";
        }
        System.out.println(levelMarks + current.data);
        for (TreeNode child : current.children) {
            print(child, level + 1);
        }
    }

    public void breadthFirstTraversal(StringBuilder result) {
        TreeNode current = this.root;
        Queue<TreeNode> queue = new LinkedList<>();
        queue.add(current);
        while (!queue.isEmpty()) {
            current = queue.poll();
            result.append(current.data).append("\n");
            queue.addAll(current.children);
        }
    }

    // Recorrido DFS Pre-Order
    public void preOrderTraversal(TreeNode current, StringBuilder result) {
        result.append(current.data).append("\n");
        for (TreeNode child : current.children) {
            preOrderTraversal(child, result);
        }
    }

    // Recorrido DFS Post-Order
    public void postOrderTraversal(TreeNode current, StringBuilder result) {
        for (TreeNode child : current.children) {
            postOrderTraversal(child, result);
        }
        result.append(current.data).append("\n");
    }

    // Recorrido DFS In-Order
    public void inOrderTraversal(TreeNode current, StringBuilder result) {
        if (current == null) return;

        int mid = current.children.size() / 2;

        for (int i = 0; i < mid; i++) {
            inOrderTraversal(current.children.get(i), result);
        }

        result.append(current.data).append("\n");

        for (int i = mid; i < current.children.size(); i++) {
            inOrderTraversal(current.children.get(i), result);
        }
    }
    // Recorrido DFS
    public void depthFirstTraversal(TreeNode current, StringBuilder result) {
        result.append(current.data).append("\n");
        for (TreeNode child : current.children) {
            depthFirstTraversal(child, result);
        }
    }
    public static void main(String[] args) {
        TreeNode root1 = new TreeNode("user/rt/courses");
        TreeNode cs016 = new TreeNode("cs016/");
        TreeNode cs252 = new TreeNode("cs252/");

        root1.addChild(cs016);
        root1.addChild(cs252);

        TreeNode grades016 = new TreeNode("grades");
        TreeNode homeworks = new TreeNode("homeworks/");
        TreeNode programs = new TreeNode("programs/");
        cs016.addChild(grades016);
        cs016.addChild(homeworks);
        cs016.addChild(programs);

        TreeNode hw1 = new TreeNode("hw1");
        TreeNode hw2 = new TreeNode("hw2");
        TreeNode hw3 = new TreeNode("hw3");
        homeworks.addChild(hw1);
        homeworks.addChild(hw2);
        homeworks.addChild(hw3);

        TreeNode pr1 = new TreeNode("pr1");
        TreeNode pr2 = new TreeNode("pr2");
        TreeNode pr3 = new TreeNode("pr3");
        programs.addChild(pr1);
        programs.addChild(pr2);
        programs.addChild(pr3);

        TreeNode projects = new TreeNode("projects/");
        TreeNode grades252 = new TreeNode("grades");
        TreeNode demos = new TreeNode("demos/");
        cs252.addChild(projects);
        cs252.addChild(grades252);
        cs252.addChild(demos);

        TreeNode papers = new TreeNode("papers/");
        projects.addChild(papers);

        TreeNode buylow = new TreeNode("buylow");
        TreeNode sellhigh = new TreeNode("sellhigh");
        papers.addChild(buylow);
        papers.addChild(sellhigh);

        TreeNode market = new TreeNode("market");
        demos.addChild(market);

        TreeRepresenting tree1 = new TreeRepresenting(root1);
        
        System.out.println("Figura 8.3 (File System):");
        tree1.print();

        StringBuilder bfsResult = new StringBuilder();
        StringBuilder dfsResult = new StringBuilder();
        StringBuilder preOrderResult = new StringBuilder();
        StringBuilder postOrderResult = new StringBuilder();
        StringBuilder inOrderResult = new StringBuilder();

        // Recorrido BFS
        System.out.println("\nRecorrido BFS:");
        tree1.breadthFirstTraversal(bfsResult);
        System.out.println(bfsResult.toString());

        // Recorrido DFS
        System.out.println("\nRecorrido DFS:");
        tree1.depthFirstTraversal(tree1.root, dfsResult);
        System.out.println(dfsResult.toString());

        // Recorrido Pre-Order
        System.out.println("\nRecorrido DFS Pre-Order:");
        tree1.preOrderTraversal(tree1.root, preOrderResult);
        System.out.println(preOrderResult.toString());

        // Recorrido Post-Order
        System.out.println("\nRecorrido DFS Post-Order:");
        tree1.postOrderTraversal(tree1.root, postOrderResult);
        System.out.println(postOrderResult.toString());

        // Recorrido In-Order
        System.out.println("\nRecorrido DFS In-Order:");
        tree1.inOrderTraversal(tree1.root, inOrderResult);
        System.out.println(inOrderResult.toString());
    }
}

