module com.figura83 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.figura83 to javafx.fxml;
    exports com.figura83;
}
